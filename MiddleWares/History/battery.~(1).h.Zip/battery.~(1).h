uint16_t get_battery_reading();
void battery_init();